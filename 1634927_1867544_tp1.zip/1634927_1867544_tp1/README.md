#Getting started
```
1. Go install nodejs at https://nodejs.org/en/download/ and take the **LTS (Recommended For Most Users)**. It's suppose to be v4.6.0
```
```
2. npm install
```

##Getting started with a bash script
```
./tp.sh -a AGLO -e PATH_DATA
```
Algo choices are : 'merge', 'bucket', 'bucketSeuil', 'mergeSeuil'
##Options
Print execution time
```
add -t
```
Print sorted array
```
add -p
```

##Example
```
./tp.sh -a merge ../donnees/testset_1000_13.txt -t -p
```

#Have fun! :)


